//
//  main.c
//  PP_HW2
//
//  Created by 陳弘翌 on 2020/10/27.
//  Copyright © 2020 陳弘翌. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>


int main(int argc, const char * argv[]) {
    return 0;
}

