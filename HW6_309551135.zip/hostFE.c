#include <stdio.h>
#include <stdlib.h>
#include "hostFE.h"
#include "helper.h"
#define MAX_SOURCE_SIZE (0x100000)
void hostFE(int filterWidth, float *filter, int imageHeight, int imageWidth,
            float *inputImage, float *outputImage, cl_device_id *device,
            cl_context *context, cl_program *program)
{
    int imageSize = imageWidth * imageHeight;
    int filterSize = filterWidth * filterWidth;
    //raccoon:Load the kernel code into the array source_str
    FILE *fp;
    char *source_str;
    size_t source_size;
 
    fp = fopen("kernel.cl", "r");
    if (!fp) {
        fprintf(stderr, "Failed to load kernel.\n");
        exit(1);
    }
    source_str = (char*)malloc(MAX_SOURCE_SIZE);
    source_size = fread( source_str, 1, MAX_SOURCE_SIZE, fp);
    fclose( fp );

    // Get platform and device information
//    printf("check\n");
    cl_int ret;
//    printf("check\n");
    // Create a command queue
    cl_command_queue command_queue = clCreateCommandQueue(*context, *device, 0, &ret);
 
    // Create memory buffers on the device for each vector 
    cl_mem source_image = clCreateBuffer(*context, CL_MEM_READ_ONLY, 
            imageSize * sizeof(float), NULL, &ret);
    cl_mem output_image = clCreateBuffer(*context, CL_MEM_WRITE_ONLY,
            imageSize * sizeof(float), NULL, &ret);
    cl_mem kernel_filter = clCreateBuffer(*context, CL_MEM_READ_ONLY, 
            filterSize * sizeof(float), NULL, &ret);
//    printf("check\n");    
    // Copy the inputImage and filter to their respective memory buffers
    ret = clEnqueueWriteBuffer(command_queue, source_image, CL_TRUE, 0,
            imageSize * sizeof(float), inputImage, 0, NULL, NULL);
    ret = clEnqueueWriteBuffer(command_queue, kernel_filter, CL_TRUE, 0, 
            filterSize * sizeof(float), filter, 0, NULL, NULL);
//    printf("check\n");
    // Create a program from the kernel source
    program = clCreateProgramWithSource(*context, 1, 
            (const char **)&source_str, (const size_t *)&source_size, &ret);
 
    // Build the program
    ret = clBuildProgram(program, 1, device, NULL, NULL, NULL);
 
    // Create the OpenCL kernel
    cl_kernel kernel = clCreateKernel(program, "convolution", &ret);
 
    // Set the arguments of the kernel
    ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&source_image);
    ret = clSetKernelArg(kernel, 1, sizeof(cl_mem), (void *)&output_image);
    ret = clSetKernelArg(kernel, 2, sizeof(cl_mem), (void *)&kernel_filter);
    ret = clSetKernelArg(kernel, 3, sizeof(int), (void*)&filterWidth);
    ret = clSetKernelArg(kernel, 4, sizeof(int), (void*)&imageHeight);
    ret = clSetKernelArg(kernel, 5, sizeof(int), (void*)&imageWidth);
//    printf("check\n");
    // Execute the OpenCL kernel on the list
    size_t global_item_size[2] = {imageWidth, imageHeight}; // Process the entire matrix
    size_t local_item_size[2] = {8, 8}; // Divide work items into groups of 64
    ret = clEnqueueNDRangeKernel(command_queue, kernel, 2, NULL, 
           global_item_size, local_item_size, 0, NULL, NULL);
//    printf("ret = %d\n", ret);
//    printf("check\n");
    // Read the memory buffer C on the device to the local variable C
    //float *result = (float*)malloc(sizeof(float) * imageHeiht * imageWidth);
    ret = clEnqueueReadBuffer(command_queue, output_image, CL_TRUE, 0, 
            imageHeight * imageWidth * sizeof(float), outputImage, 0, NULL, NULL);
//    printf("check\n");
    
    // Clean up
    ret = clFlush(command_queue);
    ret = clFinish(command_queue);
    ret = clReleaseKernel(kernel);
    ret = clReleaseProgram(program);
    ret = clReleaseMemObject(source_image);
    ret = clReleaseMemObject(output_image);
    ret = clReleaseMemObject(kernel_filter);
    ret = clReleaseCommandQueue(command_queue);
    ret = clReleaseContext(*context);
    return 0;
}
